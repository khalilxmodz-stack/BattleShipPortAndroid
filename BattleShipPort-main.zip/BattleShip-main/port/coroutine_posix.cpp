/**
 * coroutine_posix.cpp — POSIX ucontext-based coroutine implementation.
 *
 * Each coroutine uses a ucontext_t with a separate stack.
 * swapcontext() provides the resume/yield mechanism.
 */

#if !defined(_WIN32) && !defined(__ANDROID__)

/*
 * macOS marks the ucontext / swapcontext routines as deprecated and hides
 * their declarations unless _XOPEN_SOURCE is defined before <ucontext.h>.
 * Define it here (not via the target's compile definitions) so the rest of
 * the port layer still sees strictly-POSIX symbols.
 *
 * Android's bionic libc dropped getcontext/makecontext/swapcontext entirely
 * (they were never supported on aarch64). The Android branch lives in
 * coroutine_android.cpp and uses a pthread-based fallback.
 */
#if defined(__APPLE__) && !defined(_XOPEN_SOURCE)
#define _XOPEN_SOURCE 600
/* _XOPEN_SOURCE puts Darwin headers in strict-POSIX mode, which hides BSD
 * extensions like MAP_ANON(YMOUS); _DARWIN_C_SOURCE re-exposes them. */
#define _DARWIN_C_SOURCE 1
#endif

#include "coroutine.h"
#include "port_watchdog.h"

#include <ucontext.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#ifndef MAP_ANONYMOUS
#define MAP_ANONYMOUS MAP_ANON
#endif

#define MIN_STACK_SIZE 32768

struct PortCoroutine {
	ucontext_t ctx;
	ucontext_t caller_ctx;
	void (*entry)(void *);
	void *arg;
	int finished;
	char *stack_mem;   /* mmap base (guard page at the bottom) */
	size_t stack_total; /* full mapping length incl. guard page */
};

static thread_local PortCoroutine *sCurrentCoroutine = NULL;

static size_t port_page_size(void)
{
	static size_t ps = 0;
	if (ps == 0) {
		long v = sysconf(_SC_PAGESIZE);
		ps = (v > 0) ? (size_t)v : 4096;
	}
	return ps;
}

/* ========================================================================= */
/*  Internal: ucontext entry wrapper                                         */
/* ========================================================================= */

/*
 * makecontext requires a function with int parameters. A host pointer may be
 * wider than int, so on LP64/LLP64 (8-byte pointers) we split the
 * PortCoroutine pointer into a low and a high 32-bit half. On ILP32 (e.g.
 * 32-bit x86) a pointer already fits in a single int, and shifting a 4-byte
 * uintptr_t by 32 is undefined behavior — so the high half is unused there.
 */
static void ucontext_entry(unsigned int lo, unsigned int hi)
{
#if UINTPTR_MAX > 0xFFFFFFFFu
	uintptr_t ptr = ((uintptr_t)hi << 32) | (uintptr_t)lo;
#else
	(void)hi;
	uintptr_t ptr = (uintptr_t)lo;
#endif
	PortCoroutine *co = (PortCoroutine *)ptr;

	co->entry(co->arg);

	co->finished = 1;
	sCurrentCoroutine = NULL;

	/* Return to caller via the linked context (set by swapcontext). */
}

/* ========================================================================= */
/*  Public API                                                               */
/* ========================================================================= */

void port_coroutine_init_main(void)
{
	/* No-op on POSIX — ucontext doesn't require main thread conversion. */
}

PortCoroutine *port_coroutine_create(void (*entry)(void *), void *arg,
                                     size_t stack_size)
{
	PortCoroutine *co;
	uintptr_t ptr;

	if (stack_size < MIN_STACK_SIZE) {
		stack_size = MIN_STACK_SIZE;
	}

	co = (PortCoroutine *)calloc(1, sizeof(PortCoroutine));
	if (co == NULL) {
		return NULL;
	}

	/* mmap the stack with a PROT_NONE guard page at the low end so a
	 * coroutine stack overflow faults immediately (caught by the crash
	 * handler with a useful fault_addr) instead of silently corrupting
	 * adjacent heap allocations. Stacks grow down toward the guard. */
	size_t ps = port_page_size();
	stack_size = (stack_size + ps - 1) & ~(ps - 1);
	co->stack_total = stack_size + ps;
	void *mem = mmap(NULL, co->stack_total, PROT_READ | PROT_WRITE,
	                 MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	if (mem == MAP_FAILED) {
		free(co);
		return NULL;
	}
	mprotect(mem, ps, PROT_NONE);
	co->stack_mem = (char *)mem;

	co->entry = entry;
	co->arg = arg;
	co->finished = 0;

	if (getcontext(&co->ctx) == -1) {
		munmap(co->stack_mem, co->stack_total);
		free(co);
		return NULL;
	}

	co->ctx.uc_stack.ss_sp = co->stack_mem + ps;
	co->ctx.uc_stack.ss_size = stack_size;
	co->ctx.uc_link = &co->caller_ctx; /* return to caller when entry returns */

	ptr = (uintptr_t)co;
	makecontext(&co->ctx, (void (*)(void))ucontext_entry, 2,
	            (unsigned int)(ptr & 0xFFFFFFFF),
#if UINTPTR_MAX > 0xFFFFFFFFu
	            (unsigned int)(ptr >> 32));
#else
	            (unsigned int)0);
#endif

	return co;
}

void port_coroutine_destroy(PortCoroutine *co)
{
	if (co == NULL) {
		return;
	}
	if (co == sCurrentCoroutine) {
		fprintf(stderr, "SSB64: port_coroutine_destroy on current coroutine\n");
		abort();
	}
	if (co->stack_mem != NULL) {
		munmap(co->stack_mem, co->stack_total);
		co->stack_mem = NULL;
	}
	free(co);
}

void port_coroutine_resume(PortCoroutine *co)
{
	if (co == NULL || co->finished) {
		return;
	}

	/* Save the current coroutine so nested resumes restore correctly.
	 * Example: main resumes Thread5, Thread5 resumes a GObj coroutine.
	 * When the GObj coroutine yields, sCurrentCoroutine must be restored
	 * to Thread5 (not NULL) so Thread5 can still yield later. */
	PortCoroutine *prev = sCurrentCoroutine;

	sCurrentCoroutine = co;
	swapcontext(&co->caller_ctx, &co->ctx);

	/* Restore the previous coroutine context for the caller. */
	sCurrentCoroutine = prev;
}

void port_coroutine_yield(void)
{
	PortCoroutine *co = sCurrentCoroutine;
	if (co == NULL) {
		fprintf(stderr, "SSB64: port_coroutine_yield called outside coroutine\n");
		return;
	}

	port_watchdog_note_yield();

	sCurrentCoroutine = NULL;
	swapcontext(&co->ctx, &co->caller_ctx);
	/* Returns here when resumed. */
}

int port_coroutine_is_finished(PortCoroutine *co)
{
	if (co == NULL) {
		return 1;
	}
	return co->finished;
}

int port_coroutine_in_coroutine(void)
{
	return sCurrentCoroutine != NULL;
}

#endif /* !_WIN32 && !__ANDROID__ */
